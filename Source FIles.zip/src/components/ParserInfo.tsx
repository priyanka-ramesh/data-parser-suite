/**
 * ParserInfo Component
 * 
 * Educational section showing:
 * - Feature overview
 * - Usage instructions
 * - Supported formats
 * - Example data
 * 
 * Self-documents the application's capabilities.
 */

import { FileJson, Code2, Download, Zap } from 'lucide-react';

/**
 * ParserInfo Component
 * 
 * Renders static information about the parser
 * including features, instructions, and examples.
 * 
 * @returns React component
 */
export default function ParserInfo(): JSX.Element {
  return (
    <section className="parser-info">
      <div className="info-container">
        {/* Features Grid */}
        <div className="features-grid">
          {/* JSON Parser Feature */}
          <div className="feature-card">
            <div className="feature-icon">
              <FileJson size={24} />
            </div>
            <h3>JSON Parser</h3>
            <p>Parse and visualize JSON objects and arrays. Handles nested structures with automatic flattening.</p>
          </div>

          {/* XML Parser Feature */}
          <div className="feature-card">
            <div className="feature-icon">
              <Code2 size={24} />
            </div>
            <h3>XML Parser</h3>
            <p>Convert XML documents to tabular format. Supports attributes, nested elements, and mixed content.</p>
          </div>

          {/* Auto-Detect Feature */}
          <div className="feature-card">
            <div className="feature-icon">
              <Zap size={24} />
            </div>
            <h3>Auto-Detect</h3>
            <p>Automatically detects input format. Intelligently switches between JSON and XML parsing.</p>
          </div>

          {/* Export Feature */}
          <div className="feature-card">
            <div className="feature-icon">
              <Download size={24} />
            </div>
            <h3>Export</h3>
            <p>Download parsed data as CSV or JSON. Timestamped filenames for easy organization.</p>
          </div>
        </div>

        {/* Usage Guide */}
        <div className="info-section">
          <h2>How to Use</h2>
          <ol className="instruction-list">
            <li>
              <strong>Paste Data:</strong> Copy your JSON or XML data into the input panel
            </li>
            <li>
              <strong>Select Parser:</strong> Choose JSON, XML, or Auto-detect (recommended)
            </li>
            <li>
              <strong>Parse:</strong> Click the "Parse Data" button or auto-parse will trigger
            </li>
            <li>
              <strong>Review Results:</strong> Data appears in table format in the results panel
            </li>
            <li>
              <strong>Export:</strong> Download as CSV or JSON using the export controls
            </li>
          </ol>
        </div>

        {/* Example Section */}
        <div className="info-section">
          <h2>Example Data</h2>
          <div className="example-grid">
            {/* JSON Example */}
            <div className="example-card">
              <h3>JSON Example</h3>
              <pre>{`[
  {
    "id": 1,
    "name": "Alice",
    "role": "Engineer"
  },
  {
    "id": 2,
    "name": "Bob",
    "role": "Designer"
  }
]`}</pre>
            </div>

            {/* XML Example */}
            <div className="example-card">
              <h3>XML Example</h3>
              <pre>{`<?xml version="1.0"?>
<users>
  <user id="1">
    <name>Alice</name>
    <role>Engineer</role>
  </user>
  <user id="2">
    <name>Bob</name>
    <role>Designer</role>
  </user>
</users>`}</pre>
            </div>
          </div>
        </div>

        {/* Tech Stack Info */}
        <div className="info-section tech-stack">
          <h2>Built With</h2>
          <div className="tech-badges">
            <span className="badge">React 18</span>
            <span className="badge">TypeScript</span>
            <span className="badge">Vite</span>
            <span className="badge">Lucide Icons</span>
            <span className="badge">Self-Documented Code</span>
          </div>
        </div>
      </div>
    </section>
  );
}
