/**
 * EnhancedResultsPanel Component
 * 
 * Shows parsed data in multiple views:
 * - Tree view (expandable/collapsible)
 * - Table view (original)
 * - Raw JSON/XML (beautified)
 */

import { useState, useMemo } from 'react';
import { ParseResult } from '@types/parser';
import TreeView from '@components/TreeView';
import DataTable from '@components/DataTable';
import ExportControls from '@components/ExportControls';
import ErrorDisplay from '@components/ErrorDisplay';
import MetadataDisplay from '@components/MetadataDisplay';

type ViewType = 'tree' | 'table' | 'raw';

interface EnhancedResultsPanelProps {
  result: ParseResult | null;
  isLoading: boolean;
  exportFormat: 'csv' | 'json';
  onExportFormatChange: (format: 'csv' | 'json') => void;
  rawData?: unknown;
}

export default function EnhancedResultsPanel({
  result,
  isLoading,
  exportFormat,
  onExportFormatChange,
  rawData,
}: EnhancedResultsPanelProps): JSX.Element {
  const [viewType, setViewType] = useState<ViewType>('tree');
  const [searchTerm, setSearchTerm] = useState('');

  const isEmpty = useMemo(
    () => !result || result.rows.length === 0,
    [result]
  );

  const renderContent = (): JSX.Element => {
    // Loading state
    if (isLoading) {
      return (
        <div className="state-message loading-state">
          <div className="spinner" />
          <p>Parsing large dataset...</p>
        </div>
      );
    }

    // Error state
    if (result && !result.metadata.isValid && result.metadata.error) {
      return <ErrorDisplay error={result.metadata.error} />;
    }

    // Success state
    if (result && !isEmpty) {
      return (
        <>
          <MetadataDisplay metadata={result.metadata} />

          {/* View Type Selector */}
          <div className="view-selector">
            <button
              className={`view-btn ${viewType === 'tree' ? 'active' : ''}`}
              onClick={() => setViewType('tree')}
              title="Tree view (expandable)"
            >
              🌳 Tree
            </button>
            <button
              className={`view-btn ${viewType === 'table' ? 'active' : ''}`}
              onClick={() => setViewType('table')}
              title="Table view"
            >
              📊 Table
            </button>
            <button
              className={`view-btn ${viewType === 'raw' ? 'active' : ''}`}
              onClick={() => setViewType('raw')}
              title="Raw formatted data"
            >
              📄 Raw
            </button>
          </div>

          {/* Tree View */}
          {viewType === 'tree' && rawData && (
            <TreeView data={rawData} searchTerm={searchTerm} />
          )}

          {/* Table View */}
          {viewType === 'table' && (
            <DataTable rows={result.rows} columns={result.columns} />
          )}

          {/* Raw View */}
          {viewType === 'raw' && (
            <div className="raw-view">
              <pre>{JSON.stringify(rawData, null, 2)}</pre>
            </div>
          )}

          {/* Export Controls */}
          <ExportControls
            rows={result.rows}
            columns={result.columns}
            exportFormat={exportFormat}
            onExportFormatChange={onExportFormatChange}
          />
        </>
      );
    }

    // Empty state
    return (
      <div className="state-message empty-state">
        <p>Parse data to see results</p>
        <small>Use URL, upload, or paste to get started</small>
      </div>
    );
  };

  return (
    <section className="panel results-panel enhanced">
      {/* Panel Header */}
      <div className="panel-header">
        <h2>Results</h2>
        {result && !isEmpty && (
          <span className="result-stats">
            {result.rowCount.toLocaleString()} rows × {result.columns.length} columns
          </span>
        )}
      </div>

      {/* Results Content */}
      <div className="results-content">
        {renderContent()}
      </div>
    </section>
  );
}
