/**
 * ExportControls Component
 * 
 * Provides:
 * - Export format selection (CSV, JSON)
 * - Export trigger button
 * - Format-specific configuration
 * - Download file generation
 * 
 * Self-documents through:
 * - Clear export flow with console feedback
 * - Explicit error handling
 * - Format-specific helpers
 */

import { Download, FileJson, FileText } from 'lucide-react';
import { ParsedRow, ExportConfig } from '@types/parser';
import {
  exportToCsv,
  exportToJson,
  downloadFile,
  generateFilename,
} from '@utils/exportUtils';

/**
 * Props interface for ExportControls
 */
interface ExportControlsProps {
  /** Rows to export */
  rows: ParsedRow[];
  /** Columns in desired order */
  columns: string[];
  /** Selected export format */
  exportFormat: 'csv' | 'json';
  /** Callback when format changes */
  onExportFormatChange: (format: 'csv' | 'json') => void;
}

/**
 * ExportControls Component
 * 
 * Manages export functionality:
 * 1. User selects export format (CSV or JSON)
 * 2. User clicks export button
 * 3. Data is converted to selected format
 * 4. Browser download is triggered
 * 5. User receives file with timestamped filename
 * 
 * @param props - Component props
 * @returns React component
 */
export default function ExportControls({
  rows,
  columns,
  exportFormat,
  onExportFormatChange,
}: ExportControlsProps): JSX.Element {
  /**
   * Default CSV export configuration
   * 
   * Settings chosen for maximum compatibility:
   * - Headers included (standard practice)
   * - Comma delimiter (most common)
   * - Strings quoted (handles special chars)
   * - LF line endings (compatible with most systems)
   */
  const csvConfig: ExportConfig = {
    includeHeaders: true,
    delimiter: ',',
    quoteStrings: true,
    lineEnding: 'LF',
  };

  /**
   * Handles export button click
   * 
   * Process:
   * 1. Determine export format and content
   * 2. Generate timestamped filename
   * 3. Trigger browser download
   * 4. Log operation for debugging (visible in console)
   */
  const handleExport = (): void => {
    try {
      let content: string;
      let mimeType: string;
      let filename: string;

      if (exportFormat === 'csv') {
        // Export to CSV with configured settings
        content = exportToCsv(rows, columns, csvConfig);
        mimeType = 'text/csv;charset=utf-8';
        filename = generateFilename('csv');

        console.log(
          `[Export] CSV: ${rows.length} rows × ${columns.length} columns → ${filename}`
        );
      } else {
        // Export to JSON (pretty-printed)
        content = exportToJson(rows, true);
        mimeType = 'application/json;charset=utf-8';
        filename = generateFilename('json');

        console.log(`[Export] JSON: ${rows.length} rows → ${filename}`);
      }

      // Trigger browser download
      downloadFile(content, filename, mimeType);

      console.log(`[Export] Success: File downloaded`);
    } catch (error) {
      console.error('[Export] Error:', error);
      alert('Failed to export file. Please try again.');
    }
  };

  return (
    <div className="export-controls">
      <div className="export-header">
        <h3>Export Data</h3>
      </div>

      {/* Export Format Selector */}
      <div className="export-formats">
        {/* CSV Format Button */}
        <button
          onClick={() => onExportFormatChange('csv')}
          className={`format-btn ${exportFormat === 'csv' ? 'active' : ''}`}
          title="Export as CSV"
          type="button"
        >
          <FileText size={18} />
          CSV
        </button>

        {/* JSON Format Button */}
        <button
          onClick={() => onExportFormatChange('json')}
          className={`format-btn ${exportFormat === 'json' ? 'active' : ''}`}
          title="Export as JSON"
          type="button"
        >
          <FileJson size={18} />
          JSON
        </button>
      </div>

      {/* Format-Specific Info */}
      <div className="format-info">
        {exportFormat === 'csv' ? (
          <small>
            Format: CSV with headers • Delimiter: comma • Encoding: UTF-8
          </small>
        ) : (
          <small>
            Format: JSON pretty-printed • Encoding: UTF-8
          </small>
        )}
      </div>

      {/* Export Button */}
      <button
        onClick={handleExport}
        className="export-button"
        title={`Download ${exportFormat.toUpperCase()}`}
        type="button"
      >
        <Download size={18} />
        Download {exportFormat.toUpperCase()}
      </button>

      {/* Metadata */}
      <div className="export-metadata">
        <p>
          {rows.length} rows • {columns.length} columns
        </p>
      </div>
    </div>
  );
}
