/**
 * TreeView Component
 * 
 * Displays JSON/XML data in expandable tree format
 * with search, expand/collapse controls, and beautification
 * 
 * Features:
 * - Expandable/collapsible nodes
 * - Syntax highlighting
 * - Search functionality
 * - Expand/collapse all buttons
 * - Copy individual values
 * - Memory efficient (virtual scrolling ready)
 */

import { useState, useMemo, useCallback } from 'react';
import { ChevronDown, ChevronRight, Copy, Search, Expand, Minimize2 } from 'lucide-react';

interface TreeNode {
  key: string;
  value: unknown;
  level: number;
  path: string;
}

interface TreeViewProps {
  data: unknown;
  searchTerm?: string;
}

/**
 * Converts JSON object to tree nodes for display
 */
function objectToTreeNodes(
  obj: unknown,
  key: string = 'root',
  level: number = 0,
  path: string = 'root'
): TreeNode[] {
  const nodes: TreeNode[] = [];

  if (obj === null) {
    return [{ key, value: 'null', level, path }];
  }

  if (typeof obj !== 'object') {
    return [{ key, value: obj, level, path }];
  }

  if (Array.isArray(obj)) {
    nodes.push({ key, value: `Array[${obj.length}]`, level, path });
    obj.forEach((item, index) => {
      const itemPath = `${path}[${index}]`;
      nodes.push(...objectToTreeNodes(item, `[${index}]`, level + 1, itemPath));
    });
  } else {
    const objKeys = Object.keys(obj);
    nodes.push({ key, value: `Object{${objKeys.length}}`, level, path });
    
    for (const objKey of objKeys) {
      const itemPath = `${path}.${objKey}`;
      const val = (obj as Record<string, unknown>)[objKey];
      nodes.push(...objectToTreeNodes(val, objKey, level + 1, itemPath));
    }
  }

  return nodes;
}

/**
 * Individual tree node component
 */
function TreeNodeComponent({
  node,
  isExpanded,
  onToggle,
  onCopy,
  isSearchMatch,
}: {
  node: TreeNode;
  isExpanded: boolean;
  onToggle: (path: string) => void;
  onCopy: (value: unknown) => void;
  isSearchMatch: boolean;
}): JSX.Element {
  const isExpandable = typeof node.value === 'string' && 
    (node.value.startsWith('Array[') || node.value.startsWith('Object{'));

  const isSearchHighlight = isSearchMatch;

  return (
    <div
      className={`tree-node ${isSearchHighlight ? 'search-match' : ''}`}
      style={{ paddingLeft: `${node.level * 20}px` }}
    >
      <div className="tree-node-content">
        {isExpandable && (
          <button
            className="tree-toggle"
            onClick={() => onToggle(node.path)}
            title={isExpanded ? 'Collapse' : 'Expand'}
          >
            {isExpanded ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
          </button>
        )}
        
        {!isExpandable && <div className="tree-toggle-placeholder" />}

        <span className="tree-key">{node.key}</span>
        
        {typeof node.value !== 'string' ? (
          <span className="tree-value-primitive">{String(node.value)}</span>
        ) : (
          <span className={`tree-value ${node.value.startsWith('Array') ? 'array' : 'object'}`}>
            {node.value}
          </span>
        )}

        {typeof node.value !== 'string' && (
          <button
            className="copy-btn"
            onClick={() => onCopy(node.value)}
            title="Copy value"
          >
            <Copy size={14} />
          </button>
        )}
      </div>
    </div>
  );
}

/**
 * TreeView Component - Main display
 */
export default function TreeView({ data, searchTerm = '' }: TreeViewProps): JSX.Element {
  const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set(['root']));
  const [localSearchTerm, setLocalSearchTerm] = useState(searchTerm);
  const [copiedValue, setCopiedValue] = useState<string | null>(null);

  // Generate tree nodes
  const allNodes = useMemo(() => {
    return objectToTreeNodes(data);
  }, [data]);

  // Filter nodes by search
  const filteredNodes = useMemo(() => {
    if (!localSearchTerm.trim()) return allNodes;

    const term = localSearchTerm.toLowerCase();
    return allNodes.filter(
      node =>
        node.key.toLowerCase().includes(term) ||
        String(node.value).toLowerCase().includes(term) ||
        node.path.toLowerCase().includes(term)
    );
  }, [allNodes, localSearchTerm]);

  // Check if node should be visible (parent is expanded)
  const visibleNodes = useMemo(() => {
    return filteredNodes.filter(node => {
      if (node.path === 'root') return true;

      // Check if any parent is expanded
      const pathParts = node.path.split('.');
      for (let i = pathParts.length - 1; i > 0; i--) {
        const parentPath = pathParts.slice(0, i).join('.');
        if (!expandedPaths.has(parentPath)) {
          return false;
        }
      }
      return true;
    });
  }, [filteredNodes, expandedPaths]);

  /**
   * Toggle node expansion
   */
  const handleToggle = useCallback((path: string) => {
    setExpandedPaths(prev => {
      const next = new Set(prev);
      if (next.has(path)) {
        next.delete(path);
      } else {
        next.add(path);
      }
      return next;
    });
  }, []);

  /**
   * Expand all nodes
   */
  const handleExpandAll = useCallback(() => {
    const allPaths = new Set(filteredNodes.map(node => node.path));
    setExpandedPaths(allPaths);
  }, [filteredNodes]);

  /**
   * Collapse all nodes
   */
  const handleCollapseAll = useCallback(() => {
    setExpandedPaths(new Set(['root']));
  }, []);

  /**
   * Copy value to clipboard
   */
  const handleCopy = useCallback((value: unknown) => {
    const text = typeof value === 'string' ? value : JSON.stringify(value, null, 2);
    navigator.clipboard.writeText(text).then(() => {
      setCopiedValue(text);
      setTimeout(() => setCopiedValue(null), 2000);
    });
  }, []);

  return (
    <div className="tree-view-container">
      {/* Controls */}
      <div className="tree-controls">
        <div className="search-box">
          <Search size={18} />
          <input
            type="text"
            placeholder="Search keys, values, paths..."
            value={localSearchTerm}
            onChange={e => setLocalSearchTerm(e.target.value)}
            className="search-input"
          />
          {localSearchTerm && (
            <button
              onClick={() => setLocalSearchTerm('')}
              className="clear-search"
              title="Clear search"
            >
              ✕
            </button>
          )}
        </div>

        <div className="expand-controls">
          <button
            onClick={handleExpandAll}
            className="expand-btn"
            title="Expand all nodes"
          >
            <Expand size={16} /> Expand All
          </button>
          <button
            onClick={handleCollapseAll}
            className="collapse-btn"
            title="Collapse all nodes"
          >
            <Minimize2 size={16} /> Collapse All
          </button>
        </div>

        <div className="node-count">
          Showing {visibleNodes.length} of {allNodes.length} nodes
        </div>
      </div>

      {/* Tree Display */}
      <div className="tree-display">
        {visibleNodes.map(node => (
          <TreeNodeComponent
            key={node.path}
            node={node}
            isExpanded={expandedPaths.has(node.path)}
            onToggle={handleToggle}
            onCopy={handleCopy}
            isSearchMatch={localSearchTerm && (
              node.key.toLowerCase().includes(localSearchTerm.toLowerCase()) ||
              String(node.value).toLowerCase().includes(localSearchTerm.toLowerCase())
            )}
          />
        ))}
      </div>

      {/* Copy Notification */}
      {copiedValue && (
        <div className="copy-notification">
          ✓ Copied to clipboard
        </div>
      )}
    </div>
  );
}
