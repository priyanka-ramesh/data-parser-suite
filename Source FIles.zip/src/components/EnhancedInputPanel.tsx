/**
 * EnhancedInputPanel Component
 * 
 * Three input methods:
 * 1. Load from URL (with CORS handling)
 * 2. Upload files (with drag-and-drop)
 * 3. Paste data directly
 * 
 * Features:
 * - Tab-based input selection
 * - URL validation
 * - File upload with validation
 * - Textarea for pasting
 * - Size display
 * - Error handling
 */

import { useState } from 'react';
import { FileJson, Code2, Zap, Upload, Link2, Copy } from 'lucide-react';
import { fetchFromUrl, detectUrlFormat } from '@utils/urlFetcher';

type ParserType = 'json' | 'xml' | 'auto';
type InputMethod = 'url' | 'upload' | 'paste';

interface EnhancedInputPanelProps {
  input: string;
  onInputChange: (input: string) => void;
  parserType: ParserType;
  onParserChange: (type: ParserType) => void;
  onParseClick: () => void;
  isLoading: boolean;
  onParserButton: (type: ParserType) => void;
}

export default function EnhancedInputPanel({
  input,
  onInputChange,
  parserType,
  onParserChange,
  onParseClick,
  isLoading,
  onParserButton,
}: EnhancedInputPanelProps): JSX.Element {
  // State
  const [inputMethod, setInputMethod] = useState<InputMethod>('paste');
  const [urlInput, setUrlInput] = useState('');
  const [fetchLoading, setFetchLoading] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [isDragActive, setIsDragActive] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [useCorsProxy, setUseCorsProxy] = useState(false);

  const inputLength = input.length;
  const inputSizeMB = (inputLength / 1024 / 1024).toFixed(2);
  const isEmpty = inputLength === 0;

  /**
   * Handles URL fetch
   */
  const handleFetchUrl = async () => {
    if (!urlInput.trim()) {
      setFetchError('Enter a URL');
      return;
    }

    setFetchLoading(true);
    setFetchError(null);

    try {
      const result = await fetchFromUrl(urlInput, useCorsProxy);

      if (result.success && result.data) {
        onInputChange(result.data);
        setFetchError(null);
        
        // Auto-detect format
        const format = detectUrlFormat(urlInput);
        if (format !== 'unknown') {
          onParserButton(format);
        }
      } else {
        setFetchError(result.error || 'Failed to fetch URL');
      }
    } catch (error) {
      setFetchError('Error fetching URL');
    } finally {
      setFetchLoading(false);
    }
  };

  /**
   * Handles file upload
   */
  const handleFileUpload = (file: File) => {
    setUploadError(null);

    // Validate size (50MB)
    if (file.size > 50 * 1024 * 1024) {
      setUploadError('File too large. Max 50MB.');
      return;
    }

    // Validate type
    const validTypes = ['.json', '.xml', '.txt'];
    if (!validTypes.some(t => file.name.toLowerCase().endsWith(t))) {
      setUploadError('Only .json, .xml, or .txt files');
      return;
    }

    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        if (!content) {
          setUploadError('Failed to read file');
          return;
        }
        onInputChange(content);
        setUploadError(null);
      } catch {
        setUploadError('Error reading file');
      }
    };

    reader.onerror = () => {
      setUploadError('Error reading file');
    };

    reader.readAsText(file);
  };

  /**
   * Handle drag events
   */
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(true);
  };

  const handleDragLeave = () => {
    setIsDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragActive(false);

    if (e.dataTransfer.files?.[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  return (
    <section className="panel input-panel enhanced">
      {/* Panel Header */}
      <div className="panel-header">
        <h2>Input Data</h2>
        {!isEmpty && (
          <span className="input-stats">
            {inputLength.toLocaleString()} chars ({inputSizeMB} MB)
          </span>
        )}
      </div>

      {/* Input Method Tabs */}
      <div className="input-method-tabs">
        <button
          className={`tab ${inputMethod === 'url' ? 'active' : ''}`}
          onClick={() => setInputMethod('url')}
          title="Load from URL"
        >
          <Link2 size={16} /> URL
        </button>
        <button
          className={`tab ${inputMethod === 'upload' ? 'active' : ''}`}
          onClick={() => setInputMethod('upload')}
          title="Upload file"
        >
          <Upload size={16} /> Upload
        </button>
        <button
          className={`tab ${inputMethod === 'paste' ? 'active' : ''}`}
          onClick={() => setInputMethod('paste')}
          title="Paste data"
        >
          <Copy size={16} /> Paste
        </button>
      </div>

      {/* URL Input Method */}
      {inputMethod === 'url' && (
        <div className="input-section url-section">
          <div className="url-input-group">
            <input
              type="url"
              placeholder="https://api.example.com/data.json"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              disabled={fetchLoading}
              className="url-input"
            />
            <button
              onClick={handleFetchUrl}
              disabled={fetchLoading || !urlInput.trim()}
              className="fetch-btn"
            >
              {fetchLoading ? 'Fetching...' : 'Fetch'}
            </button>
          </div>

          {fetchError && <div className="error-message">{fetchError}</div>}

          <label className="cors-checkbox">
            <input
              type="checkbox"
              checked={useCorsProxy}
              onChange={(e) => setUseCorsProxy(e.target.checked)}
              disabled={fetchLoading}
            />
            Use CORS proxy (for blocked URLs)
          </label>

          <small className="input-hint">
            Supports JSON and XML URLs. Max 50MB. Fetches within 30 seconds.
          </small>
        </div>
      )}

      {/* Upload Method */}
      {inputMethod === 'upload' && (
        <div className="input-section upload-section">
          <div
            className={`file-upload-zone ${isDragActive ? 'active' : ''}`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <Upload size={24} />
            <p>Drag files here or click to browse</p>
            <small>JSON, XML, or TXT (max 50MB)</small>
            <input
              type="file"
              onChange={(e) => e.currentTarget.files?.[0] && handleFileUpload(e.currentTarget.files[0])}
              accept=".json,.xml,.txt"
              className="file-input"
              disabled={isLoading}
            />
          </div>

          {uploadError && <div className="error-message">{uploadError}</div>}
        </div>
      )}

      {/* Paste Method */}
      {inputMethod === 'paste' && (
        <div className="input-section paste-section">
          <textarea
            value={input}
            onChange={(e) => onInputChange(e.target.value)}
            placeholder="Paste JSON or XML data here..."
            className="input-textarea"
            spellCheck="false"
            disabled={isLoading}
          />
        </div>
      )}

      {/* Parser Selection */}
      <div className="parser-buttons">
        <button
          onClick={() => onParserButton('json')}
          className={`parser-btn ${parserType === 'json' ? 'active' : ''}`}
        >
          <FileJson size={16} /> JSON
        </button>
        <button
          onClick={() => onParserButton('xml')}
          className={`parser-btn ${parserType === 'xml' ? 'active' : ''}`}
        >
          <Code2 size={16} /> XML
        </button>
        <button
          onClick={() => onParserButton('auto')}
          className={`parser-btn ${parserType === 'auto' ? 'active' : ''}`}
        >
          <Zap size={16} /> Auto
        </button>
      </div>

      {/* Parse Button */}
      <button
        onClick={onParseClick}
        disabled={isEmpty || isLoading || fetchLoading}
        className={`parse-button ${isLoading ? 'loading' : ''}`}
      >
        {isLoading ? (
          <>
            <span className="spinner" />
            Parsing...
          </>
        ) : (
          'Parse Data'
        )}
      </button>
    </section>
  );
}
