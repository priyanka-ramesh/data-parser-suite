/**
 * ErrorDisplay Component
 * 
 * Displays parse errors in user-friendly format
 * with visual styling and icons.
 */

import { AlertCircle } from 'lucide-react';

/**
 * Props interface for ErrorDisplay
 */
interface ErrorDisplayProps {
  /** Error message to display */
  error: string;
}

/**
 * ErrorDisplay Component
 * 
 * Renders:
 * - Error icon
 * - Error message
 * - Helpful styling
 * 
 * @param props - Component props
 * @returns React component
 */
export default function ErrorDisplay({ error }: ErrorDisplayProps): JSX.Element {
  return (
    <div className="error-container">
      <div className="error-icon">
        <AlertCircle size={24} />
      </div>
      <div className="error-content">
        <h3>Parse Error</h3>
        <p>{error}</p>
        <small>Please check your input data and try again</small>
      </div>
    </div>
  );
}
