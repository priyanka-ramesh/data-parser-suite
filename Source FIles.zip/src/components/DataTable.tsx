/**
 * DataTable Component
 * 
 * Displays parsed data in a scrollable, responsive table format.
 * 
 * Features:
 * - Scrollable table for large datasets
 * - Truncation of long values with tooltips
 * - Column header display
 * - Zebra striping for readability
 * - Responsive design
 */

import { useMemo } from 'react';
import { ParsedRow } from '@types/parser';

/**
 * Props interface for DataTable
 */
interface DataTableProps {
  /** Array of parsed data rows */
  rows: ParsedRow[];
  /** Column names in order */
  columns: string[];
}

/**
 * Truncates long strings for table display
 * 
 * Limits displayed text to 50 characters, adds ellipsis if longer.
 * Original value preserved in title attribute for tooltip.
 * 
 * @param value - Value to potentially truncate
 * @param maxLength - Maximum display length (default: 50)
 * @returns Truncated string or original value
 */
function truncateValue(value: unknown, maxLength: number = 50): string {
  const str = String(value ?? '');
  return str.length > maxLength ? `${str.substring(0, maxLength)}...` : str;
}

/**
 * Formats cell value for display
 * 
 * Handles:
 * - null and undefined (displayed as empty)
 * - boolean values (displayed as true/false)
 * - numbers (no modification)
 * - strings (truncated if long)
 * 
 * @param value - Value to format
 * @returns Formatted display string
 */
function formatCellValue(value: unknown): string {
  if (value === null || value === undefined) {
    return '';
  }

  if (typeof value === 'boolean') {
    return value ? 'true' : 'false';
  }

  if (typeof value === 'number') {
    return String(value);
  }

  return truncateValue(String(value));
}

/**
 * DataTable Component
 * 
 * Renders:
 * - Table header with column names
 * - Data rows with cells
 * - Alternating row colors for readability
 * - Scrollable container for large datasets
 * 
 * @param props - Component props
 * @returns React component
 */
export default function DataTable({
  rows,
  columns,
}: DataTableProps): JSX.Element {
  /**
   * Memoizes row count to show summary
   */
  const rowCount = useMemo(() => rows.length, [rows]);

  /**
   * Handles early return if no data
   */
  if (rowCount === 0) {
    return (
      <div className="empty-table">
        <p>No data to display</p>
      </div>
    );
  }

  return (
    <div className="table-container">
      {/* Table Summary */}
      <div className="table-summary">
        <p>
          Showing <strong>{rowCount}</strong> row{rowCount !== 1 ? 's' : ''} with{' '}
          <strong>{columns.length}</strong> column{columns.length !== 1 ? 's' : ''}
        </p>
      </div>

      {/* Scrollable Table */}
      <div className="table-scroll">
        <table className="data-table">
          {/* Table Header */}
          <thead>
            <tr>
              <th className="row-number">#</th>
              {columns.map(column => (
                <th key={column} className="column-header" title={column}>
                  {column}
                </th>
              ))}
            </tr>
          </thead>

          {/* Table Body */}
          <tbody>
            {rows.map((row, rowIndex) => (
              <tr key={rowIndex} className={`row ${rowIndex % 2 === 0 ? 'even' : 'odd'}`}>
                <td className="row-number">{rowIndex + 1}</td>
                {columns.map(column => {
                  const value = row[column];
                  const displayValue = formatCellValue(value);
                  const fullValue = String(value ?? '');
                  const isTruncated = fullValue.length > 50;

                  return (
                    <td
                      key={`${rowIndex}-${column}`}
                      className="cell"
                      title={isTruncated ? fullValue : ''}
                    >
                      {displayValue}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
