/**
 * ResultsPanel Component
 * 
 * Displays:
 * - Parsed data in table format
 * - Metadata about parse operation
 * - Error messages if parsing failed
 * - Export controls (CSV, JSON download)
 * 
 * Composition:
 * - Uses child components for table and export controls
 * - Manages export format state
 * - Handles conditional rendering based on parse results
 */

import { useMemo } from 'react';
import { ParseResult } from '@types/parser';
import ExportControls from '@components/ExportControls';
import DataTable from '@components/DataTable';
import ErrorDisplay from '@components/ErrorDisplay';
import MetadataDisplay from '@components/MetadataDisplay';

/**
 * Props interface for ResultsPanel
 */
interface ResultsPanelProps {
  /** Parse result from parser (null if not yet parsed) */
  result: ParseResult | null;
  /** Whether parsing is currently in progress */
  isLoading: boolean;
  /** Selected export format (csv or json) */
  exportFormat: 'csv' | 'json';
  /** Callback when export format selection changes */
  onExportFormatChange: (format: 'csv' | 'json') => void;
}

/**
 * ResultsPanel Component
 * 
 * Renders:
 * 1. Loading state while parsing
 * 2. Error message if parse failed
 * 3. Metadata and statistics
 * 4. Data table with parsed rows
 * 5. Export controls
 * 
 * @param props - Component props
 * @returns React component
 */
export default function ResultsPanel({
  result,
  isLoading,
  exportFormat,
  onExportFormatChange,
}: ResultsPanelProps): JSX.Element {
  /**
   * Memoizes empty state check to avoid recalculation
   * 
   * Used to determine what message to show when no data parsed.
   */
  const isEmpty = useMemo(
    () => !result || result.rows.length === 0,
    [result]
  );

  /**
   * Determines which UI to render based on state
   * 
   * Priority:
   * 1. Loading indicator (highest priority)
   * 2. Error message (if parse failed)
   * 3. Data table (if parse succeeded)
   * 4. Empty state message
   */
  const renderContent = (): JSX.Element => {
    // Loading state
    if (isLoading) {
      return (
        <div className="state-message loading-state">
          <div className="spinner" />
          <p>Parsing data...</p>
        </div>
      );
    }

    // Error state
    if (result && !result.metadata.isValid && result.metadata.error) {
      return (
        <>
          <ErrorDisplay error={result.metadata.error} />
        </>
      );
    }

    // Success state with data
    if (result && !isEmpty) {
      return (
        <>
          <MetadataDisplay metadata={result.metadata} />
          <DataTable rows={result.rows} columns={result.columns} />
          <ExportControls
            rows={result.rows}
            columns={result.columns}
            exportFormat={exportFormat}
            onExportFormatChange={onExportFormatChange}
          />
        </>
      );
    }

    // Empty state
    return (
      <div className="state-message empty-state">
        <p>Parse data to see results here</p>
        <small>Select a parser type and click "Parse Data"</small>
      </div>
    );
  };

  return (
    <section className="panel results-panel">
      {/* Panel Header */}
      <div className="panel-header">
        <h2>Results</h2>
        {result && !isEmpty && (
          <span className="result-stats">
            {result.rowCount} rows × {result.columns.length} columns
          </span>
        )}
      </div>

      {/* Content Area */}
      <div className="results-content">
        {renderContent()}
      </div>
    </section>
  );
}
