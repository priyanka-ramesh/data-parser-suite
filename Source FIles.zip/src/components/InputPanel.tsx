/**
 * InputPanel Component
 * 
 * Responsible for:
 * - Displaying input textarea for raw data
 * - File upload with drag-and-drop support
 * - Parser type selection (JSON, XML, Auto)
 * - Parse button and loading state
 * - Input validation indicators
 * 
 * Props are self-documenting through TypeScript interfaces.
 */

import { useState } from 'react';
import { FileJson, Code2, Zap, Upload } from 'lucide-react';

/**
 * Parser type definition for input component
 */
type ParserType = 'json' | 'xml' | 'auto';

/**
 * Props interface for InputPanel component
 * Documents expected properties with descriptions
 */
interface InputPanelProps {
  /** Current input text value */
  input: string;
  /** Callback when input text changes */
  onInputChange: (input: string) => void;
  /** Currently selected parser type */
  parserType: ParserType;
  /** Callback when parser type changes */
  onParserChange: (type: ParserType) => void;
  /** Callback when parse button is clicked */
  onParseClick: () => void;
  /** Whether parsing is in progress */
  isLoading: boolean;
  /** Callback for parser button clicks */
  onParserButton: (type: ParserType) => void;
}

/**
 * InputPanel Component
 * 
 * Displays input textarea with syntax highlighting visual feedback,
 * parser selection buttons, and parse control.
 * 
 * @param props - Component props
 * @returns React component
 */
export default function InputPanel({
  input,
  onInputChange,
  parserType,
  onParserChange,
  onParseClick,
  isLoading,
  onParserButton,
}: InputPanelProps): JSX.Element {
  // File upload state
  const [isDragActive, setIsDragActive] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  /**
   * Detects input type for visual feedback
   * 
   * Used to show which parser would be auto-detected
   * and provide hint to user.
   */
  const detectInputType = (): 'json' | 'xml' | 'unknown' => {
    const trimmed = input.trim();
    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      return 'json';
    }
    if (trimmed.startsWith('<')) {
      return 'xml';
    }
    return 'unknown';
  };

  /**
   * Handles file upload - reads file content and updates input
   * 
   * Supports:
   * - JSON files (.json)
   * - XML files (.xml)
   * - Text files (.txt) containing JSON/XML
   * 
   * @param file - File to read
   */
  const handleFileUpload = (file: File): void => {
    setUploadError(null);

    // Validate file size (max 5MB)
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      setUploadError('File too large. Max 5MB.');
      return;
    }

    // Validate file type
    const validExtensions = ['.json', '.xml', '.txt'];
    const fileName = file.name.toLowerCase();
    const hasValidExtension = validExtensions.some(ext => fileName.endsWith(ext));

    if (!hasValidExtension) {
      setUploadError('Only .json, .xml, or .txt files allowed');
      return;
    }

    // Read file
    const reader = new FileReader();

    reader.onload = (e): void => {
      try {
        const content = e.target?.result as string;
        if (!content) {
          setUploadError('Failed to read file');
          return;
        }
        onInputChange(content);
        setUploadError(null);
      } catch (error) {
        setUploadError('Error reading file');
      }
    };

    reader.onerror = (): void => {
      setUploadError('Error reading file');
    };

    reader.readAsText(file);
  };

  /**
   * Handles drag over event
   */
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>): void => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(true);
  };

  /**
   * Handles drag leave event
   */
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>): void => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
  };

  /**
   * Handles drop event with file
   */
  const handleDrop = (e: React.DragEvent<HTMLDivElement>): void => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      handleFileUpload(files[0]);
    }
  };

  /**
   * Handles file input change (from file picker)
   */
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const files = e.currentTarget.files;
    if (files && files.length > 0) {
      handleFileUpload(files[0]);
    }
  };

  const detectedType = detectInputType();
  const inputLength = input.length;
  const isEmpty = inputLength === 0;

  return (
    <section className="panel input-panel">
      {/* Panel Header */}
      <div className="panel-header">
        <h2>Input Data</h2>
        <span className="input-stats">
          {inputLength > 0 && `${inputLength} chars`}
          {isEmpty && 'Paste your data here'}
        </span>
      </div>

      {/* File Upload Zone with Drag-and-Drop */}
      <div
        className={`file-upload-zone ${isDragActive ? 'active' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <Upload size={20} />
        <p>Drag JSON/XML files here or click to browse</p>
        <small>Max 5MB • .json, .xml, .txt</small>
        <input
          type="file"
          onChange={handleFileInputChange}
          accept=".json,.xml,.txt"
          className="file-input"
          disabled={isLoading}
        />
      </div>

      {/* Upload Error Message */}
      {uploadError && (
        <div className="upload-error">
          <p>{uploadError}</p>
        </div>
      )}

      {/* Parser Type Selector */}
      <div className="parser-buttons">
        {/* JSON Parser Button */}
        <button
          onClick={() => onParserButton('json')}
          className={`parser-btn ${parserType === 'json' ? 'active' : ''}`}
          title="Parse as JSON"
          type="button"
        >
          <FileJson size={18} />
          JSON
        </button>

        {/* XML Parser Button */}
        <button
          onClick={() => onParserButton('xml')}
          className={`parser-btn ${parserType === 'xml' ? 'active' : ''}`}
          title="Parse as XML"
          type="button"
        >
          <Code2 size={18} />
          XML
        </button>

        {/* Auto-Detect Parser Button */}
        <button
          onClick={() => onParserButton('auto')}
          className={`parser-btn ${parserType === 'auto' ? 'active' : ''}`}
          title="Auto-detect format"
          type="button"
        >
          <Zap size={18} />
          Auto
        </button>
      </div>

      {/* Auto-Detect Hint */}
      {parserType === 'auto' && !isEmpty && (
        <div className={`detection-hint ${detectedType}`}>
          Auto-detected: <strong>{detectedType.toUpperCase()}</strong>
        </div>
      )}

      {/* Input Textarea */}
      <textarea
        value={input}
        onChange={e => onInputChange(e.target.value)}
        placeholder="Paste JSON or XML data here..."
        className="input-textarea"
        spellCheck="false"
        disabled={isLoading}
      />

      {/* Parse Button */}
      <button
        onClick={onParseClick}
        disabled={isEmpty || isLoading}
        className={`parse-button ${isLoading ? 'loading' : ''}`}
        type="button"
      >
        {isLoading ? (
          <>
            <span className="spinner" />
            Parsing...
          </>
        ) : (
          'Parse Data'
        )}
      </button>
    </section>
  );
}
