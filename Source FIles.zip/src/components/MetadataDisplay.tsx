/**
 * MetadataDisplay Component
 * 
 * Shows metadata about parse operation:
 * - Format (JSON, XML, CSV)
 * - Parse time in milliseconds
 * - Timestamp of parse
 * - Validation status
 */

import { Clock, CheckCircle2, Zap } from 'lucide-react';
import { ParseMetadata } from '@types/parser';

/**
 * Props interface for MetadataDisplay
 */
interface MetadataDisplayProps {
  /** Parse operation metadata */
  metadata: ParseMetadata;
}

/**
 * MetadataDisplay Component
 * 
 * Renders:
 * - Format badge
 * - Parse time
 * - Timestamp
 * - Validation status
 * 
 * @param props - Component props
 * @returns React component
 */
export default function MetadataDisplay({
  metadata,
}: MetadataDisplayProps): JSX.Element {
  /**
   * Formats timestamp for display
   * Extracts time portion from ISO string
   */
  const formatTime = (isoString: string): string => {
    const date = new Date(isoString);
    return date.toLocaleTimeString();
  };

  return (
    <div className="metadata-display">
      <div className="metadata-item">
        <span className="metadata-label">Format:</span>
        <span className="metadata-value">{metadata.format.toUpperCase()}</span>
      </div>

      <div className="metadata-item">
        <Clock size={16} />
        <span className="metadata-label">Parse Time:</span>
        <span className="metadata-value">{metadata.parseTime}ms</span>
      </div>

      <div className="metadata-item">
        <span className="metadata-label">Status:</span>
        <span className={`metadata-value ${metadata.isValid ? 'valid' : 'invalid'}`}>
          {metadata.isValid ? (
            <>
              <CheckCircle2 size={16} /> Valid
            </>
          ) : (
            <>
              <Zap size={16} /> Error
            </>
          )}
        </span>
      </div>

      <div className="metadata-item">
        <span className="metadata-label">Time:</span>
        <span className="metadata-value">{formatTime(metadata.timestamp)}</span>
      </div>
    </div>
  );
}
