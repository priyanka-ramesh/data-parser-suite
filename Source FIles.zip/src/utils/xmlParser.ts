/**
 * XML Parser Module
 * 
 * Converts XML documents into tabular format for display.
 * Handles nested elements, attributes, and text content.
 * 
 * Self-documenting through:
 * - Clear parsing strategy documented in comments
 * - Type-safe node processing
 * - Explicit handling of edge cases
 */

import type { ParsedRow, ParseResult, ParseMetadata } from '@types/parser';

/**
 * Represents an XML element with its content and attributes
 */
interface XmlElement {
  /** Element tag name */
  tagName: string;
  /** Direct text content */
  text: string;
  /** Element attributes as key-value pairs */
  attributes: Record<string, string>;
  /** Child elements */
  children: XmlElement[];
}

/**
 * Extracts text content from XML node recursively.
 * Combines text nodes and text content from child elements.
 * 
 * @param node - DOM node to extract text from
 * @returns Combined text content
 */
function extractTextContent(node: Node): string {
  let text = '';

  for (const child of node.childNodes) {
    if (child.nodeType === Node.TEXT_NODE) {
      // Add text node content, trimmed of whitespace
      const nodeText = child.textContent?.trim();
      if (nodeText) {
        text += nodeText + ' ';
      }
    } else if (child.nodeType === Node.ELEMENT_NODE) {
      // Recursively extract from child elements
      text += extractTextContent(child) + ' ';
    }
  }

  return text.trim();
}

/**
 * Converts DOM Element to internal XmlElement structure.
 * Handles attributes, text, and nested elements.
 * 
 * @param element - DOM Element to convert
 * @returns Internal XmlElement representation
 */
function domElementToXmlElement(element: Element): XmlElement {
  // Extract attributes as object
  const attributes: Record<string, string> = {};
  for (const attr of element.attributes) {
    attributes[attr.name] = attr.value;
  }

  // Extract text and child elements
  const text = extractTextContent(element);
  const children: XmlElement[] = [];

  for (const child of element.children) {
    children.push(domElementToXmlElement(child as Element));
  }

  return {
    tagName: element.tagName.toLowerCase(),
    text,
    attributes,
    children,
  };
}

/**
 * Flattens XML element hierarchy into a single row.
 * 
 * Strategy:
 * - Attributes become direct columns (prefixed with @)
 * - Element text content becomes a column (prefixed with #)
 * - Nested elements use dot notation (parent.child)
 * 
 * Example:
 * <person name="John" age="30">
 *   <address>NYC</address>
 * </person>
 * 
 * Becomes:
 * { "@name": "John", "@age": "30", "address": "NYC" }
 * 
 * @param element - XML element to flatten
 * @param parentKey - Parent key for nested elements (used recursively)
 * @returns Flattened object suitable for table row
 */
function flattenXmlElement(
  element: XmlElement,
  parentKey: string = ''
): ParsedRow {
  const row: ParsedRow = {};

  // Add all attributes with @ prefix
  for (const [attrName, attrValue] of Object.entries(element.attributes)) {
    const key = parentKey ? `${parentKey}.@${attrName}` : `@${attrName}`;
    row[key] = attrValue;
  }

  // Add text content if present
  if (element.text) {
    const key = parentKey ? `${parentKey}.#text` : '#text';
    row[key] = element.text;
  }

  // Recursively flatten children, grouping by tag name
  const childrenByTag = new Map<string, XmlElement[]>();
  for (const child of element.children) {
    const current = childrenByTag.get(child.tagName) || [];
    current.push(child);
    childrenByTag.set(child.tagName, current);
  }

  // Process grouped children
  for (const [tagName, childElements] of childrenByTag.entries()) {
    const childKey = parentKey ? `${parentKey}.${tagName}` : tagName;

    if (childElements.length === 1) {
      // Single child: flatten directly
      const flattened = flattenXmlElement(childElements[0], childKey);
      Object.assign(row, flattened);
    } else {
      // Multiple children with same tag: note the count
      row[childKey] = `[${childElements.length} items]`;
    }
  }

  return row;
}

/**
 * Parses XML string and converts to tabular format.
 * 
 * Process:
 * 1. Parse XML string (catches syntax errors via DOMParser)
 * 2. Convert DOM to internal representation
 * 3. Flatten to single-row object (common for record-style XML)
 * 4. Return ParseResult with single or multiple rows
 * 
 * @param xmlString - Raw XML string to parse
 * @returns ParseResult with rows and metadata
 */
export function parseXml(xmlString: string): ParseResult {
  const startTime = performance.now();
  const metadata: ParseMetadata = {
    parseTime: 0,
    format: 'xml',
    isValid: false,
    timestamp: new Date().toISOString(),
  };

  try {
    // Parse XML using DOMParser
    // Browser API available in both browser and Node.js environments
    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlString, 'text/xml');

    // Check for parsing errors
    if (doc.getElementsByTagName('parsererror').length > 0) {
      const errorElement = doc.getElementsByTagName('parsererror')[0];
      const errorMessage = errorElement?.textContent || 'Unknown XML error';

      const endTime = performance.now();

      return {
        rows: [],
        columns: [],
        rowCount: 0,
        metadata: {
          ...metadata,
          error: `XML Parse Error: ${errorMessage}`,
          parseTime: Math.round(endTime - startTime),
        },
      };
    }

    // Get root element
    const root = doc.documentElement;
    if (!root) {
      const endTime = performance.now();
      return {
        rows: [],
        columns: [],
        rowCount: 0,
        metadata: {
          ...metadata,
          error: 'No root element found',
          parseTime: Math.round(endTime - startTime),
        },
      };
    }

    // Strategy: Check if root contains multiple child elements of same type (record-style)
    // If yes, treat each child as a row; otherwise treat entire root as single row
    const children = Array.from(root.children);
    const rows: ParsedRow[] = [];
    const columns = new Set<string>();

    if (
      children.length > 0 &&
      children.every(child => (child as Element).tagName === children[0]?.tagName)
    ) {
      // Multiple records with same tag name - treat each as row
      for (const child of children) {
        const xmlElement = domElementToXmlElement(child as Element);
        const row = flattenXmlElement(xmlElement);
        rows.push(row);

        // Collect columns
        for (const key of Object.keys(row)) {
          columns.add(key);
        }
      }
    } else {
      // Single record - treat entire root as one row
      const xmlElement = domElementToXmlElement(root);
      const row = flattenXmlElement(xmlElement);
      rows.push(row);

      // Collect columns
      for (const key of Object.keys(row)) {
        columns.add(key);
      }
    }

    const endTime = performance.now();
    const columnArray = Array.from(columns).sort();

    return {
      rows,
      columns: columnArray,
      rowCount: rows.length,
      metadata: {
        ...metadata,
        isValid: true,
        parseTime: Math.round(endTime - startTime),
      },
    };
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : 'Unknown parsing error';

    const endTime = performance.now();

    return {
      rows: [],
      columns: [],
      rowCount: 0,
      metadata: {
        ...metadata,
        error: `XML Parse Error: ${errorMessage}`,
        parseTime: Math.round(endTime - startTime),
      },
    };
  }
}
