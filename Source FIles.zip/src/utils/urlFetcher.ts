/**
 * URL Fetcher Utility
 * 
 * Fetches JSON/XML data from URLs with:
 * - CORS handling
 * - Size limits
 * - Timeout protection
 * - Error handling
 */

interface FetchResult {
  success: boolean;
  data?: string;
  error?: string;
  size: number;
  duration: number;
}

const MAX_SIZE = 50 * 1024 * 1024; // 50MB
const TIMEOUT = 30000; // 30 seconds
const CORS_PROXY = 'https://cors-anywhere.herokuapp.com/';

/**
 * Fetches data from URL with proper error handling
 * 
 * @param url - URL to fetch from
 * @param useCorsProxy - Whether to use CORS proxy
 * @returns FetchResult with data or error
 */
export async function fetchFromUrl(
  url: string,
  useCorsProxy: boolean = false
): Promise<FetchResult> {
  const startTime = performance.now();

  // Validate URL
  if (!url.trim()) {
    return {
      success: false,
      error: 'URL is empty',
      size: 0,
      duration: 0,
    };
  }

  try {
    // Validate URL format
    new URL(url); // Throws if invalid
  } catch {
    return {
      success: false,
      error: 'Invalid URL format',
      size: 0,
      duration: 0,
    };
  }

  try {
    // Create abort controller for timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), TIMEOUT);

    // Prepare fetch URL
    const fetchUrl = useCorsProxy ? `${CORS_PROXY}${url}` : url;

    // Fetch with timeout
    const response = await fetch(fetchUrl, {
      signal: controller.signal,
      headers: {
        'Accept': 'application/json, application/xml, text/xml, text/plain',
      },
    });

    clearTimeout(timeoutId);

    // Check response status
    if (!response.ok) {
      return {
        success: false,
        error: `HTTP ${response.status}: ${response.statusText}`,
        size: 0,
        duration: performance.now() - startTime,
      };
    }

    // Get content length
    const contentLength = response.headers.get('content-length');
    const size = contentLength ? parseInt(contentLength) : 0;

    // Check size limit
    if (size > MAX_SIZE) {
      return {
        success: false,
        error: `File too large (${(size / 1024 / 1024).toFixed(2)}MB). Max 50MB.`,
        size,
        duration: performance.now() - startTime,
      };
    }

    // Read response
    const data = await response.text();

    // Validate data not empty
    if (!data.trim()) {
      return {
        success: false,
        error: 'Response is empty',
        size: data.length,
        duration: performance.now() - startTime,
      };
    }

    return {
      success: true,
      data,
      size: data.length,
      duration: Math.round(performance.now() - startTime),
    };
  } catch (error) {
    const duration = performance.now() - startTime;

    if (error instanceof TypeError && error.message === 'Failed to fetch') {
      return {
        success: false,
        error: 'CORS error. Try enabling the CORS proxy or upload instead.',
        size: 0,
        duration: Math.round(duration),
      };
    }

    if (error instanceof Error && error.name === 'AbortError') {
      return {
        success: false,
        error: `Timeout (${TIMEOUT}ms). URL may be unreachable or too slow.`,
        size: 0,
        duration: Math.round(duration),
      };
    }

    const errorMsg = error instanceof Error ? error.message : 'Unknown error';
    return {
      success: false,
      error: `Failed to fetch: ${errorMsg}`,
      size: 0,
      duration: Math.round(duration),
    };
  }
}

/**
 * Validates if URL is likely JSON/XML
 * 
 * @param url - URL to check
 * @returns true if URL likely contains JSON/XML
 */
export function isDataUrl(url: string): boolean {
  const lowerUrl = url.toLowerCase();
  return (
    lowerUrl.includes('.json') ||
    lowerUrl.includes('.xml') ||
    lowerUrl.includes('/json') ||
    lowerUrl.includes('/xml') ||
    lowerUrl.includes('api') ||
    lowerUrl.includes('data')
  );
}

/**
 * Extracts file type from URL
 * 
 * @param url - URL to analyze
 * @returns 'json' | 'xml' | 'unknown'
 */
export function detectUrlFormat(url: string): 'json' | 'xml' | 'unknown' {
  const lowerUrl = url.toLowerCase();
  
  if (lowerUrl.includes('.json') || lowerUrl.includes('/json')) {
    return 'json';
  }
  
  if (lowerUrl.includes('.xml') || lowerUrl.includes('/xml')) {
    return 'xml';
  }
  
  return 'unknown';
}
