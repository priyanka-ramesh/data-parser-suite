/**
 * Export Utilities Module
 * 
 * Handles data export operations to various formats (CSV, JSON).
 * Includes proper escaping, formatting, and browser download mechanics.
 * 
 * Self-documenting through:
 * - Format-specific export functions with clear names
 * - Comprehensive JSDoc for each export type
 * - Type-safe configuration parameters
 */

import type { ParsedRow, ExportConfig } from '@types/parser';

/**
 * Escapes special characters in CSV values.
 * 
 * CSV rules:
 * - Values containing quotes, commas, or newlines must be quoted
 * - Quotes within quoted values must be doubled
 * 
 * Example:
 * Input:  'John "Johnny" Doe'
 * Output: '"John ""Johnny"" Doe"'
 * 
 * @param value - Value to escape
 * @returns Properly escaped CSV value
 */
function escapeCsvValue(value: unknown): string {
  // Convert to string
  const stringValue = String(value ?? '');

  // Check if escaping needed (contains special characters)
  const needsQuotes =
    stringValue.includes(',') ||
    stringValue.includes('"') ||
    stringValue.includes('\n') ||
    stringValue.includes('\r');

  if (!needsQuotes) {
    return stringValue;
  }

  // Escape quotes by doubling them, then wrap in quotes
  const escaped = stringValue.replace(/"/g, '""');
  return `"${escaped}"`;
}

/**
 * Converts parsed rows and columns to CSV format string.
 * 
 * Features:
 * - Configurable delimiter (comma, semicolon, tab, pipe)
 * - Optional header row
 * - Proper CSV escaping
 * - Flexible line endings (CRLF for Windows, LF for Unix)
 * 
 * @param rows - Array of parsed data rows
 * @param columns - Column names in desired order
 * @param config - Export configuration options
 * @returns CSV-formatted string
 */
export function exportToCsv(
  rows: ParsedRow[],
  columns: string[],
  config: ExportConfig
): string {
  const lines: string[] = [];

  // Add header row if configured
  if (config.includeHeaders) {
    const headerValues = columns.map(col =>
      config.quoteStrings ? escapeCsvValue(col) : col
    );
    lines.push(headerValues.join(config.delimiter));
  }

  // Add data rows
  for (const row of rows) {
    const rowValues = columns.map(col => {
      const value = row[col] ?? '';
      return config.quoteStrings ? escapeCsvValue(value) : String(value);
    });
    lines.push(rowValues.join(config.delimiter));
  }

  // Join with configured line ending
  const lineEnding = config.lineEnding === 'CRLF' ? '\r\n' : '\n';
  return lines.join(lineEnding);
}

/**
 * Converts parsed rows to JSON format string.
 * 
 * Features:
 * - Pretty-printed with 2-space indentation
 * - Maintains original data types
 * - Preserves null and boolean values
 * 
 * @param rows - Array of parsed data rows
 * @param pretty - Whether to pretty-print JSON
 * @returns JSON-formatted string
 */
export function exportToJson(rows: ParsedRow[], pretty: boolean = true): string {
  if (pretty) {
    return JSON.stringify(rows, null, 2);
  }
  return JSON.stringify(rows);
}

/**
 * Triggers browser download of provided content as file.
 * 
 * Implementation:
 * - Creates Blob from content string
 * - Generates download URL
 * - Creates temporary anchor element
 * - Triggers click event to start download
 * - Cleans up resources
 * 
 * @param content - File content as string
 * @param filename - Desired filename (e.g., 'data.csv')
 * @param mimeType - MIME type for content (e.g., 'text/csv')
 */
export function downloadFile(
  content: string,
  filename: string,
  mimeType: string
): void {
  // Create Blob from content
  const blob = new Blob([content], { type: mimeType });

  // Create object URL for download
  const url = URL.createObjectURL(blob);

  // Create and configure temporary anchor element
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.style.display = 'none';

  // Append to DOM, trigger click, remove
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);

  // Clean up object URL
  URL.revokeObjectURL(url);
}

/**
 * Generates appropriate filename with timestamp and format.
 * 
 * Filename format: `data-YYYYMMDD-HHMMSS.{ext}`
 * 
 * Example: `data-20240115-143052.csv`
 * 
 * @param format - File format (csv or json)
 * @returns Filename string
 */
export function generateFilename(format: 'csv' | 'json'): string {
  const now = new Date();

  // Format date and time components
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');

  const ext = format === 'csv' ? 'csv' : 'json';
  return `data-${year}${month}${day}-${hours}${minutes}${seconds}.${ext}`;
}
