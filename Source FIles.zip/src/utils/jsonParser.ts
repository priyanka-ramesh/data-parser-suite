/**
 * JSON Parser Module
 * 
 * Handles parsing, validation, and transformation of JSON data
 * into a tabular format with comprehensive error handling.
 * 
 * Self-documenting through:
 * - Clear function names and purposes
 * - Comprehensive JSDoc comments
 * - Type annotations for all parameters and returns
 * - Meaningful variable names
 */

import type { ParsedRow, ParseResult, ParseMetadata, ParseError } from '@types/parser';

/**
 * Flattens nested JSON objects into single-level rows suitable for table display.
 * 
 * Example:
 * Input:  { name: "John", address: { city: "NYC", zip: "10001" } }
 * Output: { name: "John", "address.city": "NYC", "address.zip": "10001" }
 * 
 * @param obj - Object to flatten
 * @param prefix - Prefix for nested keys (used internally during recursion)
 * @returns Flattened single-level object
 */
function flattenObject(
  obj: unknown,
  prefix: string = ''
): ParsedRow {
  const result: ParsedRow = {};

  // Validate input is an object
  if (typeof obj !== 'object' || obj === null || Array.isArray(obj)) {
    return result;
  }

  // Iterate through object properties
  for (const [key, value] of Object.entries(obj)) {
    // Build qualified key name with dot notation for nesting
    const qualifiedKey = prefix ? `${prefix}.${key}` : key;

    // Handle different value types
    if (value === null) {
      result[qualifiedKey] = null;
    } else if (typeof value === 'object' && !Array.isArray(value)) {
      // Recursively flatten nested objects
      const flattened = flattenObject(value, qualifiedKey);
      Object.assign(result, flattened);
    } else if (Array.isArray(value)) {
      // Store array length for visibility; full arrays handled separately
      result[qualifiedKey] = `[Array(${value.length})]`;
    } else if (typeof value === 'boolean') {
      result[qualifiedKey] = value;
    } else if (typeof value === 'number') {
      result[qualifiedKey] = value;
    } else {
      // String or other primitive
      result[qualifiedKey] = String(value);
    }
  }

  return result;
}

/**
 * Extracts unique column names from an array of parsed rows.
 * Handles varying column presence across rows (common in flexible JSON).
 * 
 * @param rows - Array of parsed rows
 * @returns Sorted array of unique column names
 */
function extractColumns(rows: ParsedRow[]): string[] {
  const columnSet = new Set<string>();

  // Collect all keys from all rows
  for (const row of rows) {
    for (const key of Object.keys(row)) {
      columnSet.add(key);
    }
  }

  // Return sorted for consistent column ordering
  return Array.from(columnSet).sort();
}

/**
 * Validates parsed JSON structure for table conversion.
 * Ensures data is suitable for tabular representation.
 * 
 * @param data - Parsed JSON data
 * @returns Validation result object
 */
function validateJsonStructure(data: unknown): {
  isValid: boolean;
  error?: string;
} {
  // Accept arrays of objects or single objects
  if (Array.isArray(data)) {
    if (data.length === 0) {
      return { isValid: false, error: 'Array is empty' };
    }

    // Check if all elements are objects (not primitives)
    const hasNonObjects = data.some(
      item => typeof item !== 'object' || item === null || Array.isArray(item)
    );

    if (hasNonObjects) {
      return {
        isValid: false,
        error: 'Array contains non-object elements. Expected array of objects.',
      };
    }

    return { isValid: true };
  }

  if (typeof data === 'object' && data !== null && !Array.isArray(data)) {
    return { isValid: true };
  }

  return {
    isValid: false,
    error: `Unsupported root type: ${typeof data}. Expected object or array of objects.`,
  };
}

/**
 * Parses JSON string and converts to tabular format (array of rows).
 * 
 * Process:
 * 1. Parse JSON string (catches syntax errors)
 * 2. Validate structure (ensures data is object/array)
 * 3. Normalize to array of objects
 * 4. Flatten nested structures
 * 5. Extract columns and return ParseResult
 * 
 * @param jsonString - Raw JSON string to parse
 * @returns ParseResult with rows, columns, and metadata
 */
export function parseJson(jsonString: string): ParseResult {
  const startTime = performance.now();
  const metadata: ParseMetadata = {
    parseTime: 0,
    format: 'json',
    isValid: false,
    timestamp: new Date().toISOString(),
  };

  try {
    // Attempt to parse JSON - will throw SyntaxError if invalid
    const parsed: unknown = JSON.parse(jsonString);

    // Validate structure is appropriate for table conversion
    const validation = validateJsonStructure(parsed);
    if (!validation.isValid) {
      return {
        rows: [],
        columns: [],
        rowCount: 0,
        metadata: {
          ...metadata,
          isValid: false,
          error: validation.error,
        },
      };
    }

    // Normalize to array of objects
    const dataArray = Array.isArray(parsed) ? parsed : [parsed];

    // Flatten each object in array
    const rows = dataArray.map(item => flattenObject(item));

    // Extract unique columns from all rows
    const columns = extractColumns(rows);

    // Calculate metrics
    const endTime = performance.now();

    return {
      rows,
      columns,
      rowCount: rows.length,
      metadata: {
        ...metadata,
        isValid: true,
        parseTime: Math.round(endTime - startTime),
      },
    };
  } catch (error) {
    // Handle JSON syntax errors
    const errorMessage =
      error instanceof SyntaxError ? error.message : 'Unknown parsing error';

    const endTime = performance.now();

    return {
      rows: [],
      columns: [],
      rowCount: 0,
      metadata: {
        ...metadata,
        isValid: false,
        error: `JSON Syntax Error: ${errorMessage}`,
        parseTime: Math.round(endTime - startTime),
      },
    };
  }
}
