/**
 * Comprehensive type definitions for data parsing operations.
 * Ensures type safety across JSON and XML parsing pipelines.
 */

/** Represents a parsed data row with flexible key-value pairs */
export interface ParsedRow {
  [key: string]: string | number | boolean | null | ParsedRow | ParsedRow[];
}

/** Result of a successful parse operation */
export interface ParseResult {
  /** Array of parsed data rows ready for table display */
  rows: ParsedRow[];
  /** Column names extracted from data */
  columns: string[];
  /** Total number of rows parsed */
  rowCount: number;
  /** Metadata about parse operation */
  metadata: ParseMetadata;
}

/** Metadata about the parsing operation */
export interface ParseMetadata {
  /** Time taken to parse in milliseconds */
  parseTime: number;
  /** Source format (json, xml, csv) */
  format: 'json' | 'xml' | 'csv';
  /** Whether data was successfully validated */
  isValid: boolean;
  /** Optional error message if parsing failed */
  error?: string;
  /** Timestamp of parse operation */
  timestamp: string;
}

/** Error information for failed parse operations */
export interface ParseError {
  /** Human-readable error message */
  message: string;
  /** Error type for categorization */
  type: 'SYNTAX' | 'VALIDATION' | 'UNSUPPORTED' | 'UNKNOWN';
  /** Line number where error occurred (if applicable) */
  line?: number;
  /** Column number where error occurred (if applicable) */
  column?: number;
}

/** Configuration for CSV export functionality */
export interface ExportConfig {
  /** Include header row with column names */
  includeHeaders: boolean;
  /** Delimiter character (comma, semicolon, tab, pipe) */
  delimiter: ',' | ';' | '\t' | '|';
  /** Quote strings containing special characters */
  quoteStrings: boolean;
  /** Use CRLF line endings (Windows) vs LF (Unix) */
  lineEnding: 'CRLF' | 'LF';
}

/** State container for parser component */
export interface ParserState {
  /** Raw input data */
  input: string;
  /** Parse result or null if not yet parsed */
  result: ParseResult | null;
  /** Error information or null if no error */
  error: ParseError | null;
  /** Loading state during parsing */
  isLoading: boolean;
  /** Selected export format */
  exportFormat: 'csv' | 'json';
}
