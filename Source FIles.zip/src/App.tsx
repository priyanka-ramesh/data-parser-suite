/**
 * Main Application Component
 * 
 * Orchestrates the entire parser application:
 * - Input handling for JSON/XML data
 * - Parser selection and execution
 * - Result display and table rendering
 * - Export functionality
 * 
 * Architecture:
 * - Functional component with React hooks
 * - State separated into concerns (input, result, format)
 * - Side effects handled via useEffect
 * - Prop drilling avoided via component composition
 */

import { useState, useCallback } from 'react';
import { ParseResult } from '@types/parser';
import { parseJson } from '@utils/jsonParser';
import { parseXml } from '@utils/xmlParser';
import EnhancedInputPanel from '@components/EnhancedInputPanel';
import EnhancedResultsPanel from '@components/EnhancedResultsPanel';
import ParserInfo from '@components/ParserInfo';
import './App.css';

type ParserType = 'json' | 'xml' | 'auto';

/**
 * Main App Component with Enhanced Features
 * 
 * Supports:
 * - Large dataset parsing (50MB+)
 * - Multiple input methods (URL, Upload, Paste)
 * - Tree view with search
 * - Original table view
 * - Raw data view
 * - CSV/JSON export
 */
export default function App(): JSX.Element {
  // ============ State ============
  const [input, setInput] = useState<string>('');
  const [rawData, setRawData] = useState<unknown>(null);
  const [result, setResult] = useState<ParseResult | null>(null);
  const [parserType, setParserType] = useState<ParserType>('auto');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [exportFormat, setExportFormat] = useState<'csv' | 'json'>('csv');

  /**
   * Detects input format automatically
   */
  const detectFormat = (str: string): 'json' | 'xml' => {
    const trimmed = str.trim();
    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      return 'json';
    }
    if (trimmed.startsWith('<')) {
      return 'xml';
    }
    return 'json';
  };

  /**
   * Parses input data and stores both result and raw data
   */
  const handleParse = useCallback(
    (dataString: string, selectedParser: ParserType): void => {
      if (!dataString.trim()) {
        setResult(null);
        setRawData(null);
        return;
      }

      setIsLoading(true);

      // Use setTimeout to prevent UI blocking with large datasets
      setTimeout(() => {
        try {
          const parseResult =
            selectedParser === 'auto'
              ? detectFormat(dataString) === 'json'
                ? parseJson(dataString)
                : parseXml(dataString)
              : selectedParser === 'json'
                ? parseJson(dataString)
                : parseXml(dataString);

          setResult(parseResult);

          // Parse raw data for tree view
          if (parseResult.metadata.isValid) {
            try {
              const rawParsed =
                parseResult.metadata.format === 'json'
                  ? JSON.parse(dataString)
                  : dataString; // XML already in string format
              setRawData(rawParsed);
            } catch {
              setRawData(null);
            }
          }
        } catch (error) {
          console.error('Parsing error:', error);
        } finally {
          setIsLoading(false);
        }
      }, 0);
    },
    []
  );

  /**
   * Handles input change
   */
  const handleInputChange = (newInput: string): void => {
    setInput(newInput);
  };

  /**
   * Handles parser type change
   */
  const handleParserChange = (newType: ParserType): void => {
    setParserType(newType);
    if (input.trim()) {
      handleParse(input, newType);
    }
  };

  /**
   * Handles parse button click
   */
  const handleParseClick = (): void => {
    handleParse(input, parserType);
  };

  /**
   * Handles parser button click
   */
  const handleParserButton = (type: ParserType): void => {
    handleParserChange(type);
  };

  return (
    <div className="app-container">
      {/* Header */}
      <header className="app-header">
        <div className="header-content">
          <h1>Advanced Data Parser</h1>
          <p>JSON • XML • Large Datasets • Tree View • Search</p>
        </div>
      </header>

      {/* Main Content */}
      <main className="app-main">
        <div className="layout-grid">
          {/* Input Panel */}
          <EnhancedInputPanel
            input={input}
            onInputChange={handleInputChange}
            parserType={parserType}
            onParserChange={handleParserChange}
            onParseClick={handleParseClick}
            isLoading={isLoading}
            onParserButton={handleParserButton}
          />

          {/* Results Panel */}
          <EnhancedResultsPanel
            result={result}
            isLoading={isLoading}
            exportFormat={exportFormat}
            onExportFormatChange={setExportFormat}
            rawData={rawData}
          />
        </div>

        {/* Info Section */}
        <ParserInfo />
      </main>

      {/* Footer */}
      <footer className="app-footer">
        <p>Advanced Data Parser • Supports Large Datasets • Built with React, TypeScript & ❤️</p>
      </footer>
    </div>
  );
}
